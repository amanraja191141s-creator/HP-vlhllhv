const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('v98.32 menu has a visible entry point, searchable categorized library and all 16 tools', () => {
  const html = read('index.html');
  const css = read('assets/css/app.css') + read('assets/css/rebuild-v98.32.css') + read('assets/css/rebuild-v98.33.css');
  const js = read('assets/js/app.js');
  assert.match(html, /id="btn-drawer-open"/);
  assert.match(html, /id="drawer-tool-search"/);
  assert.match(html, /id="drawer-favorites-list"/);
  const drawer = html.slice(html.indexOf('id="sidebar-drawer"'), html.indexOf('</aside>'));
  const ids = ['currencies','units','discount','percent','salestax','tip','loan','savings','unitprice','date','worldtime','fuelcost','fuelefficiency','gradeavg','hex','bodymetrics'];
  for (const id of ids) assert.match(drawer, new RegExp(`data-screen="${id}"`));
  for (const group of ['CONVERTERS','EVERYDAY CALCULATORS','FINANCE &amp; SHOPPING','DATE &amp; TIME','VEHICLE','STUDY &amp; WELLNESS']) assert.ok(drawer.includes(group));
  assert.match(css, /header\.app-header #btn-drawer-open \{ display:grid !important/);
  assert.match(js, /const applyToolFilter = \(\) =>/);
  assert.match(js, /renderDrawerFavorites/);
  assert.match(js, /clone\.addEventListener\('keydown'/);
});

test('every selectable currency code has a representative country or region flag mapping', () => {
  const js = read('assets/js/app.js');
  const catalogSource = js.match(/const CURRENCY_CATALOG = (\[[^;]+\]);/)[1];
  const flagsSource = js.match(/const CURRENCY_FLAG_REGIONS = (\{[\s\S]*?\});/)[1];
  const catalog = vm.runInNewContext(catalogSource);
  const flags = vm.runInNewContext(`(${flagsSource})`);
  assert.equal(catalog.length, 105);
  const missing = catalog.filter(code => !flags[code]);
  assert.equal(missing.length, 0, `missing flag mappings: ${missing.join(", ")}`);
  assert.match(js, /function currencyFlagForCode\(currencyCode\)/);
  assert.match(js, /function currencyRegionNameForCode\(currencyCode\)/);
  assert.match(js, /currency-picker-flag/);
  assert.match(js, /label\.append\(name, meta\)/);
});

test('currency picker keeps ISO code and localized name alongside the flag', () => {
  const js = read('assets/js/app.js');
  const html = read('index.html');
  assert.match(html, /id="cur-from"/);
  assert.match(html, /id="cur-to"/);
  assert.match(js, /localizedCurrencyName\(code\)/);
  assert.match(js, /currencyFlagForCode\(item\.code\)/);
  assert.match(js, /aria-selected/);
  assert.match(js, /No matching currencies/);
});

test('scientific calculator functions are grouped and all 20 function actions remain wired', () => {
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const sci = html.slice(html.indexOf('id="sci-modal-overlay"'), html.indexOf('<!-- CALCULATION HISTORY MODAL -->'));
  const functions = [...sci.matchAll(/data-fn="([^"]+)"/g)].map(match => match[1]);
  assert.equal(functions.length, 20);
  for (const group of ['CONSTANTS','POWERS &amp; ROOTS','LOGARITHMS','TRIGONOMETRY','HYPERBOLIC']) assert.ok(sci.includes(group));
  assert.match(js, /document\.querySelectorAll\('\[data-fn\]'\)/);
  assert.match(sci, /reference-memory-controls/);
  assert.match(html, /id="btn-sci-inline"/);
});

test('on-demand numeric keyboard is a safe-area-aware 4x4 sheet and retains editing actions', () => {
  const html = read('index.html');
  const css = read('assets/css/app.css') + read('assets/css/rebuild-v98.32.css') + read('assets/css/rebuild-v98.33.css');
  const js = read('assets/js/app.js');
  const keypad = html.slice(html.indexOf('id="popup-keypad-sheet"'), html.indexOf('<!-- END APP CONTAINER -->'));
  for (const key of ['7','8','9','DEL','4','5','6','NEXT','1','2','3','CLR','0','00','.','DONE']) assert.match(keypad, new RegExp(`data-popup="${key}"`));
  assert.match(css, /#popup-keypad-sheet \.popup-keypad-grid \{ height:auto !important/);
  assert.match(css, /padding-bottom:env\(safe-area-inset-bottom\)/);
  assert.match(js, /function openPopupKeypad\(inputElem\)/);
  assert.match(js, /function closePopupKeypad\(\)/);
});

test('v98.32 design system preserves tool destinations and updates release identity', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const css = read('assets/css/app.css') + read('assets/css/rebuild-v98.32.css') + read('assets/css/rebuild-v98.33.css');
  const workflow = read('.github/workflows/main.yml');
  assert.equal(pkg.version, '1.98.39-v98.39');
  assert.equal(manifest.version, pkg.version);
  assert.ok(html.includes(pkg.version));
  assert.ok(js.includes(`const APP_VERSION = '${pkg.version}'`));
  assert.match(css, /SA Calculator v98\.33 — unified premium interface/);
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.39-v98\.39'/);
  assert.match(workflow, /versionCode='1098039'/);
  for (const id of ['calc','currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime','settings']) assert.ok(html.includes(`id="screen-${id}"`));
});

# SA Calculator v98.35 — UI correction

## Fixes from the supplied Android recording
- Root cause of the cyan rounded outline at the top of tool screens: the accessibility skip-to-workspace link remained visible after touch focus in Android WebView. Touch-only focus is now hidden; keyboard-visible focus remains accessible.
- Reworked the tool drawer into a consistent two-column premium card library with readable labels, category headers, active-state clarity, compact-screen sizing, search focus, and light-theme contrast.
- Added release regression checks proving all 16 drawer tool destinations map to exactly one real screen.
- Added the generated Tools-screen design reference under `design-reference/`.

## Preserved
Calculator engines, screen IDs, navigation handlers, all 16 tool routes, history, favorites, settings, currency provider/cache, localization, themes, keyboard and Android branding.

## Release identity
- App version: `1.98.36-v98.36`
- Android versionCode: `1098036`

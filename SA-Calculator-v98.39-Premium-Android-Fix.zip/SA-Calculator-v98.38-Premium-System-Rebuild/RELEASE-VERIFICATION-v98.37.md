# Release verification — v98.37

Release: `1.98.37-v98.37`  
Android versionCode: `1098037`

## Verified
- 269 automated regression tests pass.
- JavaScript syntax checks pass.
- Android web bundle builds and includes `rebuild-v98.37.css`.
- HTML, service worker, web bundle builder and CI required-file checks reference the same stylesheet.
- YAML parses and downloadable workflow matches `.github/workflows/main.yml` byte-for-byte.
- All 18 screen IDs remain present exactly once.
- ZIP archive integrity verified.

## Pending
- Hosted Android APK build and physical-device verification remain pending.

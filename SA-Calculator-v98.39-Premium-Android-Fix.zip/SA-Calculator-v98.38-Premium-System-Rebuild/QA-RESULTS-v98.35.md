# QA Results — v98.35

- Node automated regression suite: **263 passed, 0 failed**.
- New checks: touch-only skip-link ghost suppression; keyboard focus remains visible; tool drawer has 16 unique entries mapped to 16 actual tool screens; theme contrast and search affordances.
- JavaScript syntax: verified with `node --check assets/js/app.js`.
- Android web bundle: verified with `npm run build:web`; generated `www/` includes the new v98.35 stylesheet.
- YAML parse: checked where PyYAML is available.
- APK build and physical-device verification: not run in this environment; GitHub Actions / Android device validation remains required.
